import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;

import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;

import java.util.*;
public class StudySimulation {

    public static void main(String[] args) {

        try {

            int numUser = 1;
            Calendar calendar = Calendar.getInstance();
            boolean traceFlag = false;

            CloudSim.init(numUser, calendar, traceFlag);

            Datacenter datacenter0 = createDatacenter("Study_Datacenter");

            DatacenterBroker broker = createBroker();
            int brokerId = broker.getId();

            // Create VM List (Study Slots)
            List<Vm> vmList = new ArrayList<>();

            int mips = 1000;
            long size = 10000;
            int ram = 512;
            long bw = 1000;
            int pesNumber = 1;

            for (int i = 0; i < 3; i++) {

                Vm vm = new Vm(
                        i,
                        brokerId,
                        mips,
                        pesNumber,
                        ram,
                        bw,
                        size,
                        "Xen",
                        new CloudletSchedulerTimeShared()
                );

                vmList.add(vm);
            }

            broker.submitVmList(vmList);

            // Create Cloudlets (Subjects)
            List<Cloudlet> cloudletList = new ArrayList<>();

            long fileSize = 300;
            long outputSize = 300;

            UtilizationModel utilizationModel =
                    new UtilizationModelFull();

            int[] subjectLengths = {
                    40000, // Math (Hard)
                    20000, // English (Easy)
                    30000, // Physics (Medium)
                    35000, // Chemistry
                    15000  // Biology
            };

            for (int i = 0; i < subjectLengths.length; i++) {

                Cloudlet cloudlet = new Cloudlet(
                        i,
                        subjectLengths[i],
                        pesNumber,
                        fileSize,
                        outputSize,
                        utilizationModel,
                        utilizationModel,
                        utilizationModel
                );

                cloudlet.setUserId(brokerId);
                cloudletList.add(cloudlet);
            }

            broker.submitCloudletList(cloudletList);

            CloudSim.startSimulation();

            CloudSim.stopSimulation();

            List<Cloudlet> resultList =
                    broker.getCloudletReceivedList();

            printResults(resultList);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Datacenter createDatacenter(String name) {

        List<Host> hostList = new ArrayList<>();
        List<Pe> peList = new ArrayList<>();

        for (int i = 0; i < 4; i++) {
            peList.add(new Pe(i,
                    new PeProvisionerSimple(2000)));
        }

        int hostId = 0;
        int ram = 2048;
        long storage = 1000000;
        int bw = 10000;

        hostList.add(new Host(
                hostId,
                new RamProvisionerSimple(ram),
                new BwProvisionerSimple(bw),
                storage,
                peList,
                new VmSchedulerTimeShared(peList)
        ));

        DatacenterCharacteristics characteristics =
                new DatacenterCharacteristics(
                        "x86",
                        "Linux",
                        "Xen",
                        hostList,
                        10.0,
                        3.0,
                        0.05,
                        0.001,
                        0.0
                );

        Datacenter datacenter = null;

        try {

            datacenter = new Datacenter(
                    name,
                    characteristics,
                    new VmAllocationPolicySimple(hostList),
                    new LinkedList<Storage>(),
                    0
            );

        } catch (Exception e) {
            e.printStackTrace();
        }

        return datacenter;
    }

    private static DatacenterBroker createBroker() {

        DatacenterBroker broker = null;

        try {

            broker = new DatacenterBroker("Broker");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return broker;
    }

    private static void printResults(List<Cloudlet> list) {

        System.out.println("\n===== STUDY SCHEDULE RESULTS =====");

        for (Cloudlet cloudlet : list) {

            System.out.println(
                    "Subject ID: " + cloudlet.getCloudletId()
                            + " | VM (Study Slot): "
                            + cloudlet.getVmId()
                            + " | Execution Time: "
                            + cloudlet.getActualCPUTime()
            );
        }
    }
}