import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;

import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;

import java.util.*;

public class MinMinSimulation {

    public static void main(String[] args) {

        try {

            int numUser = 1;
            Calendar calendar = Calendar.getInstance();
            boolean traceFlag = false;

            CloudSim.init(numUser, calendar, traceFlag);

            Datacenter datacenter0 =
                    createDatacenter("MinMin_DC");

            DatacenterBroker broker =
                    createBroker();

            int brokerId = broker.getId();

            // Create VMs
            List<Vm> vmList = new ArrayList<>();

            for (int i = 0; i < 3; i++) {

                Vm vm = new Vm(
                        i,
                        brokerId,
                        1000,
                        1,
                        512,
                        1000,
                        10000,
                        "Xen",
                        new CloudletSchedulerTimeShared()
                );

                vmList.add(vm);
            }

            broker.submitVmList(vmList);

            // Create Cloudlets
            List<Cloudlet> cloudletList =
                    new ArrayList<>();

            UtilizationModel utilizationModel =
                    new UtilizationModelFull();

            int[] lengths =
                    {40000, 20000, 30000, 35000, 15000};

            // Sort tasks (Min-Min logic)
            Arrays.sort(lengths);

            for (int i = 0; i < lengths.length; i++) {

                Cloudlet cloudlet =
                        new Cloudlet(
                                i,
                                lengths[i],
                                1,
                                300,
                                300,
                                utilizationModel,
                                utilizationModel,
                                utilizationModel
                        );

                cloudlet.setUserId(brokerId);

                int vmId = i % vmList.size();

                cloudlet.setVmId(vmId);

                cloudletList.add(cloudlet);
            }

            broker.submitCloudletList(cloudletList);

            CloudSim.startSimulation();

            CloudSim.stopSimulation();

            List<Cloudlet> resultList =
                    broker.getCloudletReceivedList();

            printResults(resultList);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private static Datacenter createDatacenter(String name) {

        List<Host> hostList = new ArrayList<>();
        List<Pe> peList = new ArrayList<>();

        for (int i = 0; i < 4; i++) {

            peList.add(
                    new Pe(
                            i,
                            new PeProvisionerSimple(2000)
                    )
            );
        }

        hostList.add(
                new Host(
                        0,
                        new RamProvisionerSimple(4096),
                        new BwProvisionerSimple(10000),
                        1000000,
                        peList,
                        new VmSchedulerTimeShared(peList)
                )
        );

        DatacenterCharacteristics characteristics =
                new DatacenterCharacteristics(
                        "x86",
                        "Linux",
                        "Xen",
                        hostList,
                        10.0,
                        3.0,
                        0.05,
                        0.001,
                        0.0
                );

        Datacenter datacenter = null;

        try {

            datacenter =
                    new Datacenter(
                            name,
                            characteristics,
                            new VmAllocationPolicySimple(hostList),
                            new LinkedList<Storage>(),
                            0
                    );

        } catch (Exception e) {

            e.printStackTrace();
        }

        return datacenter;
    }

    private static DatacenterBroker createBroker() {

        DatacenterBroker broker = null;

        try {

            broker =
                    new DatacenterBroker("Broker");

        } catch (Exception e) {

            e.printStackTrace();
        }

        return broker;
    }

    private static void printResults(List<Cloudlet> list) {

        System.out.println(
                "\n===== MIN-MIN RESULTS =====");

        for (Cloudlet cloudlet : list) {

            System.out.println(
                    "Subject ID: "
                            + cloudlet.getCloudletId()
                            + " | VM: "
                            + cloudlet.getVmId()
                            + " | Time: "
                            + cloudlet.getActualCPUTime()
            );
        }
    }
}